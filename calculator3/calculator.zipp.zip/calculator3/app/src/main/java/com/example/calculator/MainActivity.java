package com.example.calculator;public class MainActivity {
}
